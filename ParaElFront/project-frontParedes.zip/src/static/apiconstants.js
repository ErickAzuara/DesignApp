export default{
    api_path:"http://127.0.0.1:8000/api/"
}