export default{
    index:0,
    show:1,
    update:2,
    store:3,
    destroy:4
}