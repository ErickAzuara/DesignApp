//import logo from './logo.svg';
import './App.css';
import Index from './pages/index';
import * as React from 'react';


function App() {
  return (
    <div className="App">
      <Index></Index>
    </div>
  );
}
export default App;

