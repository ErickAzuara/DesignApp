<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GroupControl extends Controller
{
    public function index(){

    }
    public function show(){

    }
    public function destroy(){

    }
    public function update(){

    }
    public function store(){
        
    }
}
